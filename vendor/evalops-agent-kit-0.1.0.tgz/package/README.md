# EvalOps Agent Kit

Agent Kit is the local authority and runtime boundary that connects internal tools to EvalOps Platform. It centralizes authentication, device and agent registration, Agent Runtime leases, local resource mappings, native confirmation, sandboxed execution, recovery, and diagnostics.

The first production integration is Pigeon/Codex. Canonical hosted contracts and durable state remain owned by `evalops/platform`.

See [the production design](docs/superpowers/specs/2026-07-11-agent-kit-design.md).
